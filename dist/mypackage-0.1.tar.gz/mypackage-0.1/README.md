# mypackage
This library was created as an example of how to publish your own Python package it was quite painful lol.

# How to Install
You can have instruction down here